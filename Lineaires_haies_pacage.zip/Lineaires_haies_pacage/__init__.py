# -*- coding: utf-8 -*-
# Python 3

def classFactory(iface):
    from .Lineaires_haies_pacage import MainPlugin
    return MainPlugin(iface)


