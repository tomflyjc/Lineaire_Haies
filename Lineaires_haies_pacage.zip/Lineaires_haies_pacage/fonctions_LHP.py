
# -*- coding: utf-8 -*-
# Python 3

"""
/***************************************************************************
 Fichier des fonctions du plugin Lineaires_haies_package
  
                              -------------------
        begin                : 2024-07-24 
        deployment           : 2024-08-01 
        copyright            : (C) 2024 par Jean-Christophe Baudin DDT21/SUCAT/BGAT
                               
        email                : jean-christophe.baudin@cote-dor.gouv.fr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import csv
import re
import os
import unicodedata,sys
from PyQt5 import QtCore
from PyQt5 import QtGui
from PyQt5.QtGui import QFont
from PyQt5.QtCore import QVariant
from qgis.PyQt.QtWidgets import (QMessageBox)

from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.gui import *
from PyQt5.QtGui import QColor
from qgis.utils import iface
from qgis.core import *
from qgis.core import  (QgsProject,
                        QgsMapLayer,
                        QgsVectorLayer,
                        QgsFeature,
                        QgsGeometry,
                        QgsPointXY,
                        QgsProject,
                        QgsPalLayerSettings,
                        QgsVectorLayerSimpleLabeling,
                        QgsField,
                        QgsSymbol,
                        QgsMarkerSymbol,
                        QgsSimpleMarkerSymbolLayer,
                        QgsFillSymbol,
                        QgsSimpleFillSymbolLayer
                       )
from datetime import datetime
import processing
from processing import *


def resolve(name, basepath=None):
  if not basepath:
    basepath = os.path.dirname(os.path.realpath(__file__))
  return os.path.join(basepath, name)  


def getThemeIcon(theName):
    basepath = os.path.dirname(os.path.realpath(__file__))
    myDefPathIcons =basepath + "/icons/"
    myDefPathIcons = myDefPathIcons.replace("\\","/")+ theName;
    if QFile.exists(myDefPathIcons): return myDefPathIcons  
    else: return ""
  
        
def getVectorLayerByName(NomCouche):
    layermap=QgsProject.instance().mapLayers()
    for name,layer in layermap.items():
        if layer.type()==QgsMapLayer.VectorLayer and layer.name()== NomCouche:
            if layer.isValid():
               return layer
            else:
               return None


            
def select_features_by_ids(layer_name, feature_ids):
    # Obtenir la couche par son nom
    layer = QgsProject.instance().mapLayersByName(layer_name)[0]

    # Vérifier si la couche est valide
    if not layer.isValid():
        iface.messageBar().pushMessage("Erreur", f"La couche {layer_name} n'est pas valide.", level=Qgis.Critical)
        return

    # Sélectionner les features par leurs identifiants
    layer.selectByIds(feature_ids)

    # Rafraîchir la carte pour afficher la sélection
    iface.mapCanvas().refresh()
        
def creation_point_resultat(Xmin,Ymin,Xmax,Ymax,TotL,DeuxPourc,TotLTOPO,DeuxPourcTOPO,TotLTOPO_inter,DeuxPourcTOPO_inter,pacage,Long_Tot_TOPO_Haies_buffer,DeuxPourcBDTOPO_buffer,distance_buffer):
    # fonctions_LHP.creation_point_resultat(XMINF,YMINF,XMAXF,YMAXF,Long_Tot_Haies,DeuxPourc,Long_Tot_TOPO_Haies_intersection,DeuxPourcBDTOPO_intersection,pacage)
    Xpoint=round((Xmin+Xmax)/2)
    Ypoint=round((Ymin+Ymax)/2)
    Longeur=str(TotL)
    Pourc=str(DeuxPourc)
    LongeurTOPO=str(TotLTOPO)
    PourcTOPO=str(DeuxPourcTOPO)
    LongeurTOPO_inter=str(TotLTOPO_inter)
    PourcTOPO_inter=str(DeuxPourcTOPO_inter)
    LongeurTOPO_buffer=str(Long_Tot_TOPO_Haies_buffer)
    PourcTOPO_buffer=str(DeuxPourcBDTOPO_buffer)
    Tampon=str(distance_buffer)
    nom="Resultat_Longeur_haie_pacage_"+str(pacage)
    # Créer une couche de points
    layer = QgsVectorLayer("Point?crs=epsg:2154", nom, "memory")

    # Ajouter des champs à la couche
    provider = layer.dataProvider()
    provider.addAttributes([QgsField("PACAGE", QVariant.String)])
    provider.addAttributes([QgsField("Tot_Haie_m", QVariant.Double)])
    provider.addAttributes([QgsField("2Pourcent", QVariant.Double)])
    provider.addAttributes([QgsField("Tot_TOPO_m", QVariant.Double)])
    provider.addAttributes([QgsField("2P_TOPO_m", QVariant.Double)])
    provider.addAttributes([QgsField("TOPO_inter", QVariant.Double)])
    provider.addAttributes([QgsField("2P_T_inter", QVariant.Double)])
    provider.addAttributes([QgsField("Tampon"+str(Tampon)+"m", QVariant.Double)])
    provider.addAttributes([QgsField("2P_T_"+str(Tampon)+"m", QVariant.Double)])
    layer.updateFields()

    # Ajouter un point à la couche
    feature = QgsFeature()
    feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(Xpoint, Ypoint)))  # Coordonnées du point
    Values=[pacage,TotL,DeuxPourc,LongeurTOPO,PourcTOPO,LongeurTOPO_inter,PourcTOPO_inter,LongeurTOPO_buffer,PourcTOPO_buffer]
    #QMessageBox.information(None,"debug:"," Values "+str(Values))
    feature.setAttributes(Values)
    layer.startEditing()
    provider.addFeature(feature)
    layer.commitChanges()
    layer.updateExtents()

    # Ajouter la couche au projet
    QgsProject.instance().addMapLayer(layer)
    
    # Configurer la symbologie 
    # Analyse thématique
    symbol = QgsMarkerSymbol.createSimple({'name': 'circle', 'color': 'black', 'size': '1'})  # Taille réduite à 0 pour ne pas le voir
    layer.renderer().setSymbol(symbol)

    # Configurer les étiquettes
    label_settings = QgsPalLayerSettings()
    label_settings.fieldName = ''  # Ne pas utiliser un champ directement
    label_settings.isExpression = True
    #label_settings.expression = 'concat("pacage", \':\\n\', "Longeur")'
    label_settings.expression = 'concat("pacage", \':\\n\', "Longeur", \'m\\n\', "Pourc",\'m\')'  # Expression pour concaténer les champs avec un saut de ligne
    label_settings.enabled = True
    label_settings.placement = QgsPalLayerSettings.OverPoint

    # Appliquer les paramètres d'étiquette à la couche
    layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
    layer.setLabelsEnabled(True)

    # Rafraîchir la carte pour afficher les étiquettes
    layer.triggerRepaint()
    return layer
       


def create_buffer_geometry(selected_features, distance_buffer):
    """
    Crée un tampon unique pour les entités sélectionnées et retourne l'objet géométrique du tampon.

    :param selected_features: Liste des entités sélectionnées.
    :param distance_buffer: Distance du tampon.
    :return: Objet géométrique du tampon unique.
    """
    # Créer une couche temporaire en mémoire pour stocker les entités sélectionnées
    temp_layer = QgsVectorLayer("Polygon?crs=EPSG:4326", "temp_layer", "memory")
    temp_layer.startEditing()
    temp_layer.dataProvider().addAttributes(selected_features[0].fields())
    temp_layer.updateFields()

    for feature in selected_features:
        temp_layer.addFeature(feature)

    temp_layer.commitChanges()

    # Définir les paramètres de l'algorithme de tampon
    params = {
        'INPUT': temp_layer,
        'DISTANCE': distance_buffer,
        'SEGMENTS': 5,  # Nombre de segments pour approcher les courbes (ajustez selon vos besoins)
        'END_CAP_STYLE': 0,  # Style de capuchon de fin (0 = Round, 1 = Flat, 2 = Square)
        'JOIN_STYLE': 0,  # Style de jonction (0 = Round, 1 = Mitre, 2 = Bevel)
        'MITER_LIMIT': 2,  # Limite de l'onglet (ajustez selon vos besoins)
        'DISSOLVE': True,  # Dissoudre les tampons en un seul polygone
        'OUTPUT': 'memory:'
    }

    # Exécuter l'algorithme de tampon
    result = processing.run("native:buffer", params)

    # Obtenir la couche de sortie
    output_layer = result['OUTPUT']

    # Vérifier si la couche de sortie est valide
    if not output_layer.isValid():
        print("Échec de la création du tampon.")
        return None

    # Obtenir la première (et unique) entité de la couche de sortie
    feat_buffer = next(output_layer.getFeatures())

    # Retourner la géométrie du tampon
    return feat_buffer.geometry()
    
    
def Exports_cartographiques(path_name,rapport_name,couche_haie,couche_BDTOPO_haie,couche_parcelles,projet,manager,Xmin,Ymin,Xmax,Ymax,TotL,DeuxPourc,TotLTOPO,DeuxPourcTOPO,TotLTOPO_inter,DeuxPourcTOPO_inter,Long_Tot_TOPO_Haies_buffer,DeuxPourcBDTOPO_buffer,distance_buffer,pacage,tot_parcelle_select):
    #fonctions_LHP.Exports_cartographiques(rep_out_path,rapport_name,layer_haies,layer_BDTOPO_haies,layer_parcelles,project,manager,XMINF,YMINF,XMAXF,YMAXF,Long_Tot_Haies,DeuxPourc,Long_Tot_TOPO_Haies,DeuxPourcBDTOPO,Long_Tot_TOPO_Haies_intersection,DeuxPourcBDTOPO_intersection,pacage)
    LPac=TotL
    Pourc2=DeuxPourc
    LTopo=TotLTOPO
    Pourc2Topo=DeuxPourcTOPO
    LTopoInter=TotLTOPO_inter
    Pourc2TopoInter=DeuxPourcTOPO_inter 
    LongeurTOPO_buffer=str(Long_Tot_TOPO_Haies_buffer)
    PourcTOPO_buffer=str(DeuxPourcBDTOPO_buffer)
    TamponD=str(distance_buffer)
    nbparcelles=tot_parcelle_select
    Pacage=pacage
    chemin=path_name.replace("\\","/")
    project=projet
    # rappel des modalite_fond_de_carte fct de leur id: 0 = Scan 25, 1= Orthophoto, 2 = rapprochée
    # ------------------------------------------------
              # Création d'une mise en page
    # ------------------------------------------------
     
    # Attention! Il faut nommer chaque mise en page / layout avec un nom différent,
    # sans quoi on a une message d'erreur "RuntimeError: wrapped C/C++ object of type QgsPrintLayout has been deleted "
    # voir https://gis.stackexchange.com/questions/436047/runtimeerror-wrapped-c-c-object-of-type-qgsprintlayout-has-been-deleted
    # on nommera les layout d'après le nom de la couche  layoutName = str(couche)
    # ou mieux : on détruit le layout une fois utiliser !
    # https://library.virginia.edu/data/articles//how-to-create-and-export-print-layouts-in-python-for-qgis-3 
    
    # project = QgsProject.instance()             #gets a reference to the project instance
    # manager = project.layoutManager()           #gets a reference to the layout manager
    layoutName = str(rapport_name)
    # on doit vérifier et éventuellement dézingier tous les derniers layout pour se prémunir des erreurs si un layout.name() existe déjà !
    # https://gis.stackexchange.com/questions/436047/runtimeerror-wrapped-c-c-object-of-type-qgsprintlayout-has-been-deleted
    # https://library.virginia.edu/data/articles//how-to-create-and-export-print-layouts-in-python-for-qgis-3 
    # https://gis.stackexchange.com/questions/311390/pyqgis-managing-print-layouts
    layouts_list = manager.printLayouts()
    liste_layout_names=[]
    
    for idx, lay in enumerate(layouts_list):
        liste_layout_names.append(lay.name())

    for layout in layouts_list:
        if layout.name() == layoutName:
            manager.removeLayout(layout)
           
    liste_layout_names=[]       
    for idx, lay in enumerate(layouts_list):
        liste_layout_names.append(lay.name())        
    
    # Generating an empty layout
    layout = QgsPrintLayout(project)            #makes a new print layout object, takes a QgsProject as argument
    layout.initializeDefaults()  #create default map canvas
    layout.setName(layoutName)
     # on ajoute un layout ayant nom de la couche
    manager.addLayout(layout)
    # Prepare project and layout generation
     
    
    # Open layers
    project.addMapLayer(couche_parcelles)
    project.addMapLayer(couche_haie)
    project.addMapLayer(couche_BDTOPO_haie)
    
    
    # la feuille A4 paysage mesure 297mm en largeur et 210mm en hauteur   
    page = QgsLayoutItemPage(layout)
    page.setPageSize('A4',  QgsLayoutItemPage.Landscape)
    page_center = page.pageSize().width() / 2
    
    # Composeur d'impression: 
    # Tous les éléments de la mise page comme carte, étiquette, 
    # …sont des objets représentés par des classes qui héritent de la classe de base QgsLayoutItem.
    # Carte:
    # This adds a map item to the Print Layout 
    map = QgsLayoutItemMap(layout) # Load an empty map
    map.setRect(20, 20, 20, 20)  
    
    canvas = iface.mapCanvas()
    Etendu_du_Canvas=canvas.extent()
    # Set Extent
    
    rectangle = QgsRectangle(Xmin,Ymin,Xmax,Ymax)  #an example of how to set map extent with coordinates
    map.setExtent(rectangle)
                
    # Move: les arguments sont:
    # la distance à partir du bord gauche du layout, 
    # puis la distance à partir du bord haut.
    map.attemptMove(QgsLayoutPoint(5, 28, QgsUnitTypes.LayoutMillimeters))
    # Resize :  QgsLayoutSize(largeur, hauteur , unités employées)
    map.attemptResize(QgsLayoutSize(240, 180, QgsUnitTypes.LayoutMillimeters))
    # a4 = QPageSize().size(QPageSize.A4, QPageSize.Millimeter)
    # map.attemptResize(QgsLayoutSize(a4.height(),  a4.width()))
    map.zoomToExtent(iface.mapCanvas().extent())
    
    # Layout
    layout.addLayoutItem(map)
     
    # Titre de la carte
    # This adds labels to the map
    nom_de_la_carte=rapport_name.replace("_"," ")
    nom_de_la_carte+=' ('+str(nbparcelles)+' parcelles)\n'
    title = QgsLayoutItemLabel(layout)
    title.setText(nom_de_la_carte)
    title.setFont(QFont("Arial",16))
    y=6
    x=15
    layout.addLayoutItem(title)
    title.attemptMove(QgsLayoutPoint(x, y, QgsUnitTypes.LayoutMillimeters))
    title.adjustSizeToText()
    y += title.boundingRect().height()
    title.attemptResize(QgsLayoutSize(x+title.boundingRect().width(),y))
    layout.addLayoutItem(title)
    
    commentaire =  "Le linéaire de haies d'après la couche Haie de la BDTOPO de V3-4 est calculé selon trois hypothèses: \n"
    commentaire += "- hypothèse haute = une partie au moins des objets haies intersecte les parcelles,\n"
    commentaire += "- hypothèse basse = seules les parties de haies strictement dans les parcelles sont comptées,\n" 
    commentaire += "- hypothèse avec tampon = seules les parties de haies jusqu'à "+str(TamponD)+"m des parcelles sont comptées." 
    subtitle = QgsLayoutItemLabel(layout)
    subtitle.setText(commentaire)
    subtitle.setFont(QFont("Arial",7))
    y=13
    x=15
    layout.addLayoutItem(subtitle)
    subtitle.attemptMove(QgsLayoutPoint(x, y, QgsUnitTypes.LayoutMillimeters))
    subtitle.adjustSizeToText()
    y += subtitle.boundingRect().height()
    subtitle.attemptResize(QgsLayoutSize(x+subtitle.boundingRect().width(),y))
    layout.addLayoutItem(subtitle)
    
    # Echelle graphique
    # on prépare la taille de la sclebar avec Etendu_du_Canvas qui est un QgsRectangle
    # https://qgis.org/pyqgis/3.2/core/other/QgsRectangle.html 
    scaleBar = QgsLayoutItemScaleBar(layout)
    scaleBar.applyDefaultSettings()
    scaleBar.setLinkedMap(map)
    scaleBar.setStyle('Single Box')    # setStyle: 'Single Box', 'Double Box', 'Line Ticks Middle', 'Line Ticks Down', 'Line Ticks Up', 'Numeric'
    scaleBar.setNumberOfSegmentsLeft(0)
    scaleBar.setNumberOfSegments(2)
    # on choisir d'avoir toujours deux segments dans l'échelle quelle doit etre la taille d'un segment ?
    H_Canvas=Etendu_du_Canvas.height()
    L_Canvas=Etendu_du_Canvas.width()
    if H_Canvas > L_Canvas: 
        Dmax_Canvas=H_Canvas
    else:
        Dmax_Canvas=L_Canvas
    # on va se donner comme taille de la barre d'échelle 1/5 de la taille maximale de l'étendue du Canevas de la carte
    scaleBar_total_size=int(Dmax_Canvas/5)
    scaleBar.setMapUnitsPerScaleBarUnit(1)  # Sets the number of map units per scale bar unit used by the scalebar:
    if scaleBar_total_size <= 100:
        scaleBar.setUnits(QgsUnitTypes.DistanceMeters)
        scaleBar.setUnitLabel("m")
        scaleBar.setUnitsPerSegment(25)
    elif scaleBar_total_size <= 500:
        scaleBar.setUnits(QgsUnitTypes.DistanceMeters)
        scaleBar.setUnitLabel("m")
        scaleBar.setUnitsPerSegment(100)
    elif scaleBar_total_size <=  1000:
        scaleBar.setUnits(QgsUnitTypes.DistanceMeters)
        scaleBar.setUnitLabel("m")
        scaleBar.setUnitsPerSegment(250)
    elif scaleBar_total_size <=  10000:
        scaleBar.setUnits(QgsUnitTypes.DistanceKilometers)
        scaleBar.setUnitLabel("km")
        scaleBar.setUnitsPerSegment(0.5) 
    elif scaleBar_total_size <=  50000:
        scaleBar.setUnits(QgsUnitTypes.DistanceKilometers)
        scaleBar.setUnitLabel("km")
        scaleBar.setUnitsPerSegment(2.5)
    scaleBar.setBackgroundEnabled(1) # 0 pour ne pas avoir de background/fond
    layout.addLayoutItem(scaleBar)
    # Move: les arguments sont:
    # la distance à partir du bord gauche du layout, 
    # puis la distance à partir du bord haut.
    scaleBar.attemptMove(QgsLayoutPoint(5, 195, QgsUnitTypes.LayoutMillimeters)) # attention on se répère dans la map !
     
    # Fleche nord
    fleche_nord= QgsLayoutItemPicture(layout)
    image_fleche_nord = getThemeIcon("Nord.jpg")
    fleche_nord.setPicturePath(image_fleche_nord)
    layout.addLayoutItem(fleche_nord)
    fleche_nord.attemptResize(QgsLayoutSize(20, 20, QgsUnitTypes.LayoutMillimeters))
    fleche_nord.attemptMove(QgsLayoutPoint(275, 4, QgsUnitTypes.LayoutMillimeters))
    
    # légende
    ############################################################################
    # pour en savoir plus:
    # https://hg-map.fr/tutos/73-qgis-et-python?start=5
    # https://library.virginia.edu/data/articles//how-to-create-and-export-print-layouts-in-python-for-qgis-3
    # https://github.com/epurpur/PyQGIS-Scripts/blob/master/CreateLayoutManagerAndExport.py
    # https://api.qgis.org/api/classQgsLegendStyle.html#acae0c6c735f4cb36f30fc53df74bd84e%20to%20change%20styles%20for%20other%20legend%20blocks%20(match%20%22Fonts%20and%20Text%20Formatting%22%20section)
    # https://qgis.org/pyqgis/3.28/core/QgsLegendStyle.html
    # https://api.qgis.org/api/classQgsLegendStyle.html#a56a491c6b4fad6c112c687c4a57dde6d
    # https://gis.stackexchange.com/questions/452695/setting-layout-legend-style-in-pyqgis
    #
    ##################################################################################################
    legend = QgsLayoutItemLegend(layout)
    # Définir le style du titre de la légende
    title_style = QgsLegendStyle()  # make new style
    title_style.setFont(QFont("Arial",12,1,False))
    legend.setStyle(QgsLegendStyle.Title,title_style) # set style to the legend title
    legend.setTitle("Legende:")
    legend.setFrameEnabled(True)
    legend.setFrameStrokeWidth(QgsLayoutMeasurement(0.4))
    layerTree = QgsLayerTree()
    layerTree.addLayer(couche_parcelles)
    layerTree.addLayer(couche_haie)
    layerTree.addLayer(couche_BDTOPO_haie)
    legend.model().setRootGroup(layerTree)
    legend.setLinkedMap(map) # map is an instance of QgsLayoutItemMap
    layout.addLayoutItem(legend)
    legend.setColumnSpace(30) 
    y=182 #y=28
    x=165
    legend.attemptMove(QgsLayoutPoint(x, y, QgsUnitTypes.LayoutMillimeters))

    # ajout d'un polygone
    # create
    polygon = QPolygonF()
    polygon.append(QPointF(2.0, 2.0))
    polygon.append(QPointF(295.0, 2.0)) # A4 = 297 de largeur en paysage
    polygon.append(QPointF(295.0, 27.0))
    polygon.append(QPointF(2.0, 27.0))
    polygon.append(QPointF(2.0, 2.0))
    mon_polygone = QgsLayoutItemPolyline(polygon,layout)
    layout.addLayoutItem(mon_polygone)
    # style
    props = {}
    props["color"] = "0,5,0,55"
    props["width"] = "2.0"
    props["capstyle"] = "square"
    props["style"] = "solid"
    props["style_border"] = "solid"
    props["color_border"] = "black"
    props["width_border"] = "1.0"
    props["joinstyle"] = "miter"
    style = QgsLineSymbol.createSimple(props)
    mon_polygone.setSymbol(style)
    
    #Ajout des statistiques de longueurs de haies
    text_stat='Pour les parcelles du pacage choisi le linéaire de haies est de:\n'
    text_stat += 'selon Telepac-SNA-DE-REFERENCE-VG-HAIES: \n'
    text_stat += str(LPac)+'m avec 2%= '+str(Pourc2)+'\n\n'
    text_stat += 'selon BDTOPO avec hypothèse: \n'
    text_stat += ' - haute: '+ str(LTopo)+'m dont 2%= '+str(Pourc2Topo)+'m \n'
    text_stat += ' - basse: '+ str(LTopoInter)+'m dont 2%= '+str(Pourc2TopoInter)+'m \n'
    text_stat += ' - avec Tampon'+str(TamponD)+'m: '+ str(LongeurTOPO_buffer)+'m dont 2%= '+str(PourcTOPO_buffer)+'m \n'
      
    StatLabel = QgsLayoutItemLabel(layout)
    StatLabel.setText(text_stat)
    StatLabel.setFont(QFont("Arial", 7))
    StatLabel.adjustSizeToText()
    layout.addLayoutItem(StatLabel)
    # Resize :  QgsLayoutSize(largeur, hauteur , unités employées)
    StatLabel.attemptResize(QgsLayoutSize(40, 80, QgsUnitTypes.LayoutMillimeters))
    #StatLabel.attemptMove(QgsLayoutPoint(248, 95, QgsUnitTypes.LayoutMillimeters))
    StatLabel.attemptMove(QgsLayoutPoint(248, 32, QgsUnitTypes.LayoutMillimeters))
    
    # copyrigth couches fond de plans:
    base='Sources des fonds cartographiques: \n'
    texte_FDP=base+'MASA–Telepac-SURFACES-PARCELLES-GRAPHIQUES-CONSTATEES\n'
    texte_FDP=texte_FDP+'MASA–Telepac-SNA-DE-REFERENCE-VG-HAIES\n'
    texte_FDP=texte_FDP+'©IGN - BDTOPO®\n'
    texte_FDP=texte_FDP+'©IGN - SCAN25®\n' 
    copyrigth_FDP = QgsLayoutItemLabel(layout)
    copyrigth_FDP.setText(texte_FDP)
    copyrigth_FDP.setFont(QFont("Arial", 7))
    copyrigth_FDP.adjustSizeToText()
    layout.addLayoutItem(copyrigth_FDP)
    copyrigth_FDP.attemptResize(QgsLayoutSize(40, 20, QgsUnitTypes.LayoutMillimeters))
    copyrigth_FDP.attemptMove(QgsLayoutPoint(246,130, QgsUnitTypes.LayoutMillimeters))
        
    # logo administration
    # un cadre est ajouté par défaut au label pour le supprimer :
    # logo.setFrameEnabled(False)
    logo = QgsLayoutItemPicture(layout)
    Marianne_ddt21 = getThemeIcon("PREF_Cote_d_Or_CMJN_295_432px_Marianne.jpg")
    logo.setPicturePath(Marianne_ddt21)
    layout.addLayoutItem(logo)
    logo.attemptResize(QgsLayoutSize(50, 50, QgsUnitTypes.LayoutMillimeters))
    logo.attemptMove(QgsLayoutPoint(250, 150, QgsUnitTypes.LayoutMillimeters))
    
    # copyrigth DDT
    date=datetime.strftime(datetime.now(), "%d/%m/%Y")
    credit_text = QgsLayoutItemLabel(layout)
    credit_text.setText("© DDT21 le "+str(date))
    credit_text.setFont(QFont("Arial", 10))
    #credit_text.setTextFormat(Font("Arial", 10)) # comment l'utiliser
    credit_text.adjustSizeToText()
    layout.addLayoutItem(credit_text)
    credit_text.attemptResize(QgsLayoutSize(40, 20, QgsUnitTypes.LayoutMillimeters))
    credit_text.attemptMove(QgsLayoutPoint(250,200, QgsUnitTypes.LayoutMillimeters))
    
    # this creates a QgsLayoutExporter object:
    exporter= QgsLayoutExporter(layout) 
    exporter.layout().refresh() # Refresh the layout before printing
    nom_du_fichier_carte_pdf= rapport_name +'.pdf'
    pdf_path = os.path.join(chemin, nom_du_fichier_carte_pdf)
    exporter.exportToPdf(pdf_path, QgsLayoutExporter.PdfExportSettings())   # this exports a pdf of the layout object
        
    nom_du_fichier_carte_jpeg= rapport_name +'.jpeg'
    jpeg_path = os.path.join(chemin, nom_du_fichier_carte_jpeg)
    # this exports an image of the layout object
    exporter.exportToImage(jpeg_path, QgsLayoutExporter.ImageExportSettings())
    
    return layout, manager, layoutName

    
def layout_cleaner(project):
    project = QgsProject.instance()   #gets a reference to the project instance
    manager = project.layoutManager() #gets a reference to the layout manager
    layout = QgsPrintLayout(project)   #makes a new print layout object, takes a QgsProject as argument
    layouts_list = manager.printLayouts()
    for layout in layouts_list:
        manager.removeLayout(layout)
    manager.clear()
        
        
def Exports_GeoPDF(path_name,rapport_name,projet,manager,XMINF,YMINF,XMAXF,YMAXF,pacage):
    # pour en savoir plus:
    # https://north-road.com/2019/09/03/qgis-3-10-loves-geopdf/
    # https://qgis.org/pyqgis/3.28/
    # https://www.cadlinecommunity.co.uk/hc/en-us/articles/360003823717-QGIS-Creating-a-GeoPDF
    # https://qgis.org/pyqgis/3.28/core/QgsLayoutExporter.html#qgis.core.QgsLayoutExporter.PdfExportSettings.appendGeoreference
    # https://gis.stackexchange.com/questions/370656/can-i-create-a-geospatial-pdf-in-python-without-using-gis-software
   
    project=projet
    layouts_list = manager.printLayouts()
    liste_layout_names=[]
    
    for idx, lay in enumerate(layouts_list):
        liste_layout_names.append(lay.name())

    for layout in layouts_list:
        if layout.name() == layoutName:
            manager.removeLayout(layout)

    layout = QgsPrintLayout(project)            #makes a new print layout object, takes a QgsProject as argument
    layout.initializeDefaults()  #create default map canvas
    layoutName = str(rapport_name)
    layout.setName(layoutName)
     # on ajoute un layout ayant nom de la couche
    manager.addLayout(layout)
    
    # la feuille A4 paysage mesure 297mm en largeur et 210mm en hauteur   
    page = QgsLayoutItemPage(layout)
    page.setPageSize('A4',  QgsLayoutItemPage.Landscape)
    page_center = page.pageSize().width() / 2
    
    # Composeur d'impression: 
    # Tous les éléments de la mise page comme carte, étiquette, 
    # …sont des objets représentés par des classes qui héritent de la classe de base QgsLayoutItem.

    # Carte:
    # This adds a map item to the Print Layout 
    map = QgsLayoutItemMap(layout)
    map.setRect(20, 20, 20, 20)  
    # Set Extent
    canvas = iface.mapCanvas()

    rec=rec_emprise
    rectangle = QgsRectangle(XMINF,YMINF,XMAXF,YMAXF)  
    map.setExtent(rectangle)
            
    # Move: les arguments sont:
    # la distance à partir du bord gauche du layout, 
    # puis la distance à partir du bord haut.
    map.attemptMove(QgsLayoutPoint(5, 26, QgsUnitTypes.LayoutMillimeters))
    map.attemptResize(QgsLayoutSize(240, 180, QgsUnitTypes.LayoutMillimeters))  # Resize :  QgsLayoutSize(largeur, hauteur , unités employées)
    map.zoomToExtent(iface.mapCanvas().extent())
    layout.addLayoutItem(map)
    
    # https://courses.spatialthoughts.com/pyqgis-in-a-day.html#turn-a-layer-onoff
    
    # Titre de la carte
    nom_de_la_carte=rapport_name+str(pacage) 
    title = QgsLayoutItemLabel(layout)
    title.setText(nom_de_la_carte)
    # title.setFont(QFont("Verdana",28))
    title.setFont(QFont("Arial",13))
    # https://gis.stackexchange.com/questions/459233/setting-width-for-label-adjustsizetotext-in-pyqgis
    y=5
    x=7
    layout.addLayoutItem(title)
    title.attemptMove(QgsLayoutPoint(x, y, QgsUnitTypes.LayoutMillimeters))
    title.adjustSizeToText()
    y += title.boundingRect().height()
    title.attemptResize(QgsLayoutSize(x+title.boundingRect().width(),y))
    layout.addLayoutItem(title)
   
    # Echelle graphique
    # on prépare la taille de la sclebar avec Etendu_du_Canvas qui est un QgsRectangle
    # https://qgis.org/pyqgis/3.2/core/other/QgsRectangle.html 
    scaleBar = QgsLayoutItemScaleBar(layout)
    scaleBar.applyDefaultSettings()
    scaleBar.setLinkedMap(map)
    scaleBar.setStyle('Single Box')  # setStyle: 'Single Box', 'Double Box', 'Line Ticks Middle', 'Line Ticks Down', 'Line Ticks Up', 'Numeric'
    scaleBar.setNumberOfSegmentsLeft(0)
    scaleBar.setNumberOfSegments(2)
    # on choisir d'avoir toujours deux segments dans l'échelle ... quelle doit etre la taille d'un segment ?
    Etendu_du_Canvas=canvas.extent()
    H_Canvas=Etendu_du_Canvas.height()
    L_Canvas=Etendu_du_Canvas.width()
    if H_Canvas > L_Canvas: 
        Dmax_Canvas=H_Canvas
    else:
        Dmax_Canvas=L_Canvas
    # on va se donner comme taille de la barre d'échelle 1/5 de la taille maximale de l'étendue du Canevas de la carte
    scaleBar_total_size=int(Dmax_Canvas/5)
    scaleBar.setMapUnitsPerScaleBarUnit(1)  # Sets the number of map units per scale bar unit used by the scalebar:
    if scaleBar_total_size <= 100:
        scaleBar.setUnits(QgsUnitTypes.DistanceMeters)
        scaleBar.setUnitLabel("m")
        scaleBar.setUnitsPerSegment(25)
    elif scaleBar_total_size <= 500:
        scaleBar.setUnits(QgsUnitTypes.DistanceMeters)
        scaleBar.setUnitLabel("m")
        scaleBar.setUnitsPerSegment(100)
    elif scaleBar_total_size <=  1000:
        scaleBar.setUnits(QgsUnitTypes.DistanceMeters)
        scaleBar.setUnitLabel("m")
        scaleBar.setUnitsPerSegment(250)
    elif scaleBar_total_size <=  10000:
        scaleBar.setUnits(QgsUnitTypes.DistanceKilometers)
        scaleBar.setUnitLabel("km")
        scaleBar.setUnitsPerSegment(0.5) 
    elif scaleBar_total_size <=  50000:
        scaleBar.setUnits(QgsUnitTypes.DistanceKilometers)
        scaleBar.setUnitLabel("km")
        scaleBar.setUnitsPerSegment(2.5)
    scaleBar.setBackgroundEnabled(1) # 0 pour ne pas avoir de background/fond
    layout.addLayoutItem(scaleBar)
    scaleBar.attemptMove(QgsLayoutPoint(5, 195, QgsUnitTypes.LayoutMillimeters)) # attention on se répère dans la map !
     
    # Fleche nord
    fleche_nord= QgsLayoutItemPicture(layout)
    image_fleche_nord = getThemeIcon("Nord.jpg")
    fleche_nord.setPicturePath(image_fleche_nord)
    layout.addLayoutItem(fleche_nord)
    fleche_nord.attemptResize(QgsLayoutSize(20, 20, QgsUnitTypes.LayoutMillimeters))
    fleche_nord.attemptMove(QgsLayoutPoint(275, 4, QgsUnitTypes.LayoutMillimeters))
    
      
    #############################################################################
    # Ajout d'un cadre autour du titre
    
    cadre = QPolygonF()
    cadre.append(QPointF(2.0, 2.0))
    cadre.append(QPointF(295.0, 2.0)) # A4 = 297 de largeur en paysage
    cadre.append(QPointF(295.0, 25.0))
    cadre.append(QPointF(2.0, 25.0))
    cadre.append(QPointF(2.0, 2.0))
    mon_cadre = QgsLayoutItemPolyline(cadre,layout)
    layout.addLayoutItem(mon_cadre)
    # style
    props = {}
    props["color"] = "0,5,0,55"
    props["width"] = "2.0"
    props["capstyle"] = "square"
    props["style"] = "solid"
    props["style_border"] = "solid"
    props["color_border"] = "black"
    props["width_border"] = "1.0"
    props["joinstyle"] = "miter"
    style = QgsLineSymbol.createSimple(props)
    mon_cadre.setSymbol(style)

    # copyrigth couches fond de plans:
    base='Sources des fonds cartographiques: \n'
    texte_FDP=base+'MASA–Telepac-SURFACES-PARCELLES-GRAPHIQUES-CONSTATEES\n'
    texte_FDP=texte_FDP+'MASA–Telepac-SNA-DE-REFERENCE-VG-HAIES\n'
    texte_FDP=texte_FDP+'©IGN - SCAN25® Version 1 \n' 
    copyrigth_FDP = QgsLayoutItemLabel(layout)
    copyrigth_FDP.setText(texte_FDP)
    copyrigth_FDP.setFont(QFont("Arial", 7))
    copyrigth_FDP.adjustSizeToText()
    layout.addLayoutItem(copyrigth_FDP)
    copyrigth_FDP.attemptResize(QgsLayoutSize(40, 20, QgsUnitTypes.LayoutMillimeters))
    copyrigth_FDP.attemptMove(QgsLayoutPoint(250,160, QgsUnitTypes.LayoutMillimeters))
        
    # logo administration
    # un cadre est ajouté par défaut au label pour le supprimer :
    # logo.setFrameEnabled(False)
    logo = QgsLayoutItemPicture(layout)
    Marianne_ddt21 = getThemeIcon("PREF_Cote_d_Or_CMJN_295_432px_Marianne.jpg")
    logo.setPicturePath(Marianne_ddt21)
    layout.addLayoutItem(logo)
    logo.attemptResize(QgsLayoutSize(30, 30, QgsUnitTypes.LayoutMillimeters))
    logo.attemptMove(QgsLayoutPoint(255, 165, QgsUnitTypes.LayoutMillimeters))
    
    # copyrigth DDT
    date=datetime.strftime(datetime.now(), "%d/%m/%Y")
    credit_text = QgsLayoutItemLabel(layout)
    # credit_text.setText("© DDT21 le:"+'\n'+str(date))
    credit_text.setText("© DDT21 le: "+str(date))
    credit_text.setFont(QFont("Arial", 10))
    credit_text.adjustSizeToText()
    layout.addLayoutItem(credit_text)
    credit_text.attemptResize(QgsLayoutSize(40, 20, QgsUnitTypes.LayoutMillimeters))
    credit_text.attemptMove(QgsLayoutPoint(250,200, QgsUnitTypes.LayoutMillimeters))
    
    ###########################################
    #                   légende
    ##########################################
    # on veut gérer le cartouche legende en fonction du nombre de figurés des analyses thématiques des layers
    # si ca ne rentre pas en une colonne dans le geopdf A4 paysage, on déporte sur autre pdf ce taille A4,A3 ou A0
    #################################
    # https://hg-map.fr/tutos/73-qgis-et-python?start=5
    legend = QgsLayoutItemLegend(layout)
    legend.setTitle("Legende")
   
    # https://library.virginia.edu/data/articles//how-to-create-and-export-print-layouts-in-python-for-qgis-3
    # https://github.com/epurpur/PyQGIS-Scripts/blob/master/CreateLayoutManagerAndExport.py
    # on ne veut que la légende de la couche de zonage active....
    # Checks layer tree objects and stores them in a list. This includes csv tables
    # checked_layers = [layer.name() for layer in QgsProject().instance().layerTreeRoot().children() if layer.isVisible()]
    # get map layer objects of checked layers by matching their names and store those in a list
    checked_layers=liste_noms_couches_intersectees
    layersToAdd = [layer for layer in QgsProject().instance().mapLayers().values() if layer.name() in checked_layers]
    root = QgsLayerTree()
    for layer in layersToAdd:
        root.addLayer(layer) #add layer objects to the layer tree
    legend.model().setRootGroup(root)
    
    ###############################################################
    # comment compter le nombre de figurés des différentes couches pour gerer la publication des legendes ?
    # https://gis.stackexchange.com/questions/464170/adjust-symbol-size-for-color-ramp-in-print-layout-legend-with-python
    nb_items_legendes=0
    for layer in layersToAdd:
        tree_view = iface.layerTreeView()
        model = tree_view.layerTreeModel()
        layer_tree = model.rootGroup().findLayer(layer.id()) 
        legend_items = model.layerLegendNodes(layer_tree)
        nb_items=len(legend_items) # on a donc le nombre d'items d'une couche 
        nb_items_legendes+= nb_items
        
    #############
    if nb_items_legendes < 13: # si la legende prend plus de 12 lignes on la déporte dans un autre pdf car sinon elle déborde du geopdf
        style = QgsLegendStyle()  # make new style
        style.setFont(QFont("Arial",7,1,False))
        legend.setStyle(QgsLegendStyle.Group,style)
        style_base = QgsLegendStyle()  # make new style
        style_base.setFont(QFont("Arial",6,1,False))
        legend.setStyle(QgsLegendStyle.SymbolLabel,style_base)
        legend.rstyle(QgsLegendStyle.Symbol).setMargin( QgsLegendStyle.Top , 4) # pour decaller le texte du symbole
        
        legend.setLinkedMap(map) # map is an instance of QgsLayoutItemMap
        legend.setLegendFilterByMapEnabled(True) # pour n'avoir que les nodes de lé legende dans l'emprise
        legend.refresh()
        layout.addLayoutItem(legend)
        legend.setColumnSpace(35)
        y=25
        x=220
        legend.attemptMove(QgsLayoutPoint(x, y, QgsUnitTypes.LayoutMillimeters))
    else: # si il y a plus de 12 items dans une legende on l'exporte à part !
        Export_Legende_pdf(path_name,rapport_name,projet,manager,liste_noms_couches_intersectees,nb_items_legendes)
    
    exporter= QgsLayoutExporter(layout) # this creates a QgsLayoutExporter object
    exporter.layout().refresh() # Refresh the layout before printing
    # setup settings
    settings =  QgsLayoutExporter.PdfExportSettings()
    settings.dpi =90 # 300
    # pour créer un geopdf !
    # https://api.qgis.org/api/3.28/structQgsLayoutExporter_1_1PdfExportSettings.html#a93ddb66c1e1f541a1bed511a41f9e396
    settings.writeGeoPdf = True
        
    date_H_M=datetime.strftime(datetime.now(), "%Y_%m_%d_%Hh_%Mmin")
    file_rapport= str(path_name)
    path_rapport=file_rapport.replace("\\","/")
    nom_export="Rapport_cartographique_d_interrogation_ADS_des_parcelles_"
    nom_du_fichier_tableau_pdf = nom_export+str(date_H_M)+'.pdf'
    
    pdf_path = os.path.join(path_rapport, nom_du_fichier_tableau_pdf)
    exporter.exportToPdf(pdf_path, settings)
    
    return layout, manager, layoutName,nb_items_legendes,liste_noms_couches_intersectees

 