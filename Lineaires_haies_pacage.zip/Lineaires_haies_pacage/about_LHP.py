# -*- coding: utf-8 -*-
# Python 3

from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import *
from PyQt5 import QtCore
from PyQt5.QtGui import QFont, QImage, QPixmap, QBrush, QColor, QPalette
from PyQt5.QtWidgets import QGridLayout, QLabel, QTextEdit, QPushButton, QSpacerItem, QSizePolicy, QFrame, QDialog, QApplication,QMessageBox
# Import libs 
import sys, os.path; sys.path.append(os.path.dirname(os.path.abspath(__file__)))
 
#Fonction de reconstruction du chemin absolu vers la ressource image
def resolve(name, basepath = None):
  if not basepath:
    basepath = os.path.dirname(os.path.realpath(__file__))
  return os.path.join(basepath, name)  

def getThemeIcon(theName):
    basepath = os.path.dirname(os.path.realpath(__file__))
    myDefPathIcons =basepath + "/icons/"
    myDefPathIcons = myDefPathIcons.replace("\\","/")+ theName;
    if QFile.exists(myDefPathIcons): return myDefPathIcons  
    else: return ""
    
class Ui_Dialog(object):

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(QtCore.QSize(QtCore.QRect(0,0,500,600).size()).expandedTo(Dialog.minimumSizeHint()))

        self.gridlayout = QGridLayout(Dialog)
        self.gridlayout.setObjectName("gridlayout")

        self.label_2 = QLabel(Dialog)
        self.labelImage = QLabel(Dialog)

        carIcon = QImage(getThemeIcon("LHP.jpg"))
        self.labelImage.setPixmap(QPixmap.fromImage(carIcon))

        font = QFont()
        font.setPointSize(15) 
        font.setWeight(50) 
        font.setBold(True)
        self.label_2.setFont(font)
        self.label_2.setTextFormat(QtCore.Qt.RichText)
        self.label_2.setObjectName("label_2")
        self.gridlayout.addWidget(self.label_2,0,0,1,2)
        self.gridlayout.addWidget(self.labelImage,0,2,1,1)

        self.textEdit = QTextEdit(Dialog)

        palette = QPalette()

        brush = QBrush(QColor(0,0,0,0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QPalette.Active,QPalette.Base,brush)

        brush = QBrush(QColor(0,0,0,0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QPalette.Inactive,QPalette.Base,brush)

        brush = QBrush(QColor(255,255,255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QPalette.Disabled,QPalette.Base,brush)
        self.textEdit.setPalette(palette)
        self.textEdit.setAutoFillBackground(True)
        self.textEdit.width = 450
        self.textEdit.height = 550
        #self.textEdit.setFrameShape(QFrame.NoFrame)
        #self.textEdit.setFrameShadow(QFrame.Plain)
        self.textEdit.setReadOnly(True)
        self.textEdit.setObjectName("textEdit")
        self.textEdit.setTextInteractionFlags(QtCore.Qt.TextBrowserInteraction)
       
        self.gridlayout.addWidget(self.textEdit,1,0,5,3) 

        self.pushButton = QPushButton(Dialog)
        self.pushButton.setObjectName("pushButton")
        self.gridlayout.addWidget(self.pushButton,6,2,1,1) 

        spacerItem = QSpacerItem(20,40,QSizePolicy.Minimum,QSizePolicy.Expanding)
        self.gridlayout.addItem(spacerItem,5,2,1,1)

        self.retranslateUi(Dialog)
        self.pushButton.clicked.connect(Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QApplication.translate("Dialog","Lineaires_haies_pacage", None))
        self.label_2.setText(QApplication.translate("Dialog", "Lineaires_haies_pacage V2", None))
        self.textEdit.setHtml(QApplication.translate("Dialog", "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
        "p, li { white-space: pre-wrap; }\n"
        "</style></head><body style=\" font-family:\'Sans Serif\'; font-size:8pt; font-weight:450; font-style:normal;\">\n"
        "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:8pt;\"><span style=\" font-weight:600;\">"
        "<br>Lineaires_haies_pacage :</span><br>"+
        "<br> Ce plugin est conçu pour les agents du Service Economie Agricole et Environnement des Exploitations de la DDT souhaitant disposer dans Qgis_3"+ 
        " d'une fonctionnalité dédié à l'instruction des demandes de modifications des linéaires de haies, à partir des couches téléchargées sur ISIS.<br>" + 
        " <br>L'outil calcule la somme totale des longueurs de haies pour l'ensemble de parcelles ayant un certain numero PACAGE."+ 
        " Les parcelles étant sélectionnées par intersection entre les polygones des deux couches:<br>"+ 
       
        " <br>Pour télécharger les données:<br>                                                                             "
        " <br>https://isis.telepac.agriculture.gouv.fr/telepac/auth/accueil.action<br>"+
        " <br>Une fois login et mdp renseignés,on va dans Extractions de données.<br>"+
        " <br>Pour la campagne de l'année en cours on télécharge deux couches :<br>"+
        " <br>- SURFACES ANNEE - PARCELLES GRAPHIQUES CONSTATEES <br>"+
        "             qui contient les numéros de pacage attribut 'PACAGE'" +
        " <br> - SURFACES ANNEE - SNA de reference dont utilisera la table SNA-DE-REFERENCE-2024_021_VG.shp<br>"+
        "               qui contient les longueurs de haies - attribut 'LONGUEUR' "+
        "           <br>et aussi les surfaces de haies - attribut 'SURF_ADM' dont on se servira quand LONGUEUR est null ! <br> "+ 
        " <br>On décompresse dans 'W:/5_AUTRES_DONNEES/AGRICULTURE/TELECHARGEMENT_TELEPAC/"+"\n"+
        " A partir de  de SNA-DE-REFERENCE-2024_021_VG.shp, on crée la couche SNA-DE-REFERENCE-2024_021_VG_HAIE_ONLY.shp" + 
        " pour l'attribut 'TYPE' like 'Haie' <br>"+ 
        "<br> On crée encore dans SNA-DE-REFERENCE-2024_021_VG_HAIE_ONLY.shp avec QGIS un attribut 'long_m' avec to_real(LONGUEUR) "+ 
        "<br> On remplace enfin dans long_m les valeurs nulle par round($area/LARGEUR) <br>"+ 
        "<br> Cette extension ne fait pas partie du moteur de Qgis. Toute demande est à adresser à l'auteur : </p></td><br></tr></table>"
        "<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p>\n"
        "<p style=\"margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">"
        #"<font color='#0000FF'><b><u> Jean-Christophe Baudin</u></b></font><br><br>"
        "<b>jean-christophe.baudin@cote-dor.gouv.fr</b><br><b>DDT21 SUCAT/BGAT</b><br>"
        "<br><i>Version 2.0.0 (11 octobre 2024).</i></p></body></html>", None))
        self.pushButton.setText(QApplication.translate("Dialog", "OK", None))

