# -*- coding: utf-8 -*-
# Python 3

"""
/***************************************************************************
 Fichier des fonctions du plugin Lineaires_haies_pacage

 Ce code calcule à partir des couches télécharées sur ISIS 
 la somme totale des LONGUEUR pour l'ensemble de parcelles ayant un certain numero PACAGE
 ces parcelles étant sélectionnées par intersection entre les polygones des deux couches

 https://isis.telepac.agriculture.gouv.fr/telepac/auth/accueil.action
 une fois login et mdp renseignés,on va dans Extractions de données
 Pour la campagne de l'année en cours
 ou télécharge :
 - SURFACES ANNEE - PARCELLES GRAPHIQUES CONSTATEES
 - SURFACES ANNEE - SNA de reference dont utlisera la table SNA-DE-REFERENCE-2024_021_VG.shp
 On décompresse dans 'W:/5_AUTRES_DONNEES/AGRICULTURE/TELECHARGEMENT_TELEPAC/

   

                              -------------------
        begin                : 2024-07-24 
        deployment           : 2024-10-16 
        copyright            : (C) 2024 par Jean-Christophe Baudin DDT21/SUCAT/BGAT
                              
        email                : jean-christophe.baudin@cote-dor.gouv.fr
 ***************************************************************************/

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.gui import *
from PyQt5.QtGui import QColor
from qgis.utils import iface
from qgis.core import *

from qgis.core import  (QgsProject,
                        QgsMapLayer,
                        QgsVectorLayer,
                        QgsFeature,
                        QgsGeometry,
                        QgsPointXY,
                        QgsProject,
                        QgsPalLayerSettings,
                        QgsVectorLayerSimpleLabeling,
                        QgsField,
                        QgsSymbol,
                        QgsMarkerSymbol,
                        QgsSimpleMarkerSymbolLayer,
                        QgsFillSymbol,
                        QgsSimpleFillSymbolLayer
                       )                      
# Import libs 
import sys, os.path; sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from datetime import datetime

import processing
from processing import *
import fonctions_LHP
import doAbout_LHP

#Fonction de reconstruction du chemin absolu vers une ressource du plugin
def resolve(name, basepath=None):
  if not basepath:
    basepath = os.path.dirname(os.path.realpath(__file__))
  return os.path.join(basepath, name)  

def getThemeIcon(theName):
    basepath = os.path.dirname(os.path.realpath(__file__))
    myDefPathIcons =basepath + "/icons/"
    myDefPathIcons = myDefPathIcons.replace("\\","/")+ theName;
    if QFile.exists(myDefPathIcons): return myDefPathIcons  
    else: return ""
    
class Ui_Dialog(object):
    def setupUi(self,Dialog):
    
        ##############################################################################################################################################
        #                Parametrage du plugin par rapport au projet QGIS local- déclaration des variables - couches à utiliser
        ##############################################################################################################################################
        global nom_couche_parcelles,nom_couche_haies,nom_couche_BDTOPO_haies,Liste_des_couches_necessaires,d_buffer
        
        couche_parcelles='W:/2_DOSSIERS/AGRICULTURE/EXPLOITATION_ELEVAGE/STRUCTURE/haies/SURFACES-2024-PARCELLES-GRAPHIQUES-CONSTATEES_021_20240726.shp'
        nom_couche_parcelles='SURFACES-2024-PARCELLES-GRAPHIQUES'
        couche_haies='W:/2_DOSSIERS/AGRICULTURE/EXPLOITATION_ELEVAGE/STRUCTURE/haies/SNA-DE-REFERENCE-2024_021_VG_HAIE_ONLY.shp'
        nom_couche_haies='Haies-2024'
        couche_BDTOPO_haies='N:/BDTOPO/OCCUPATION_DU_SOL/HAIE.shp'
        nom_couche_BDTOPO_haies='Haies-BDTOPO_V3-4'
        d_buffer=3 # pour 3 mètres autour des parcelles permet de capter des haies limitrophes
        
        Liste_des_couches_necessaires={}
        Liste_des_couches_necessaires[nom_couche_parcelles]=[couche_parcelles]
        Liste_des_couches_necessaires[nom_couche_haies]=[couche_haies]
        Liste_des_couches_necessaires[nom_couche_BDTOPO_haies]=[couche_BDTOPO_haies]
        
        # pour le fond de plan ici scan 25 
        couche_SCAN_25='N:/CARTES/SCAN_25/SCAN25_3-1_TOUR_TIFF_LAMB93_D021_2024-02-01/SCAN25/3_SUPPLEMENTS_LIVRAISON_2024-06-00028/SC25_TOUR_TIF_LAMB93_D21/mosaique.vrt'
        nom_SCAN_25='SCAN25'
        Liste_des_fonds_de_plan_necessaires={}
        Liste_des_fonds_de_plan_necessaires[nom_SCAN_25]=[couche_SCAN_25]
              
        message_liste='\n\n'
        for nom_couche in list(Liste_des_couches_necessaires.keys()):
            nom=str(Liste_des_couches_necessaires[nom_couche][0])
            message_liste= message_liste+nom+'\n\n'
        message_liste=message_liste+'Il vous appartient de vérifier si ces données sont bien à jour !'
        QMessageBox.information(None,"Avertissement:","  Les calculs seront effectués à partir des couches de la liste suivante: "+str(message_liste))
        
         
        #------------------------------------------------------------------------------------------------------------------
        #    Vérifications de la présence ou non (alors ajout) des données dédiées au calcul des linéaires de haies
        #------------------------------------------------------------------------------------------------------------------
                 
        layermap=QgsProject.instance().mapLayers()
        
        for nom_couche in list(Liste_des_fonds_de_plan_necessaires.keys()):
            absence = True
            for name, layer in layermap.items():
                if layer.type() == QgsMapLayer.RasterLayer and layer.name() == nom_couche:
                    absence = False
            if absence:
                rlayer = QgsRasterLayer(Liste_des_fonds_de_plan_necessaires[nom_couche][0], nom_couche)
                # Vérifier si la couche est valide
                if not rlayer.isValid():
                    print(f"Erreur : La couche {nom_couche} n'est pas valide.")
                else:
                    # Ajouter la couche au projet QGIS
                    QgsProject.instance().addMapLayer(rlayer)
                    print(f"La couche {nom_couche} a été ajoutée au projet QGIS.")
           
        for nom_couche in list(Liste_des_couches_necessaires.keys()):
            absence=True
            for name,layer in layermap.items():
                if layer.type()== QgsMapLayer.VectorLayer and layer.name() == nom_couche:
                    absence=False
            if absence: 
                vlayer = QgsVectorLayer(Liste_des_couches_necessaires[nom_couche][0], nom_couche, "ogr")
                # Vérifier si la couche est valide
                if not vlayer.isValid():
                    print(f"Erreur : La couche {nom_couche} n'est pas valide.")
                else:
                    # Ajouter la couche au projet QGIS
                    QgsProject.instance().addMapLayer(vlayer)
                    print(f"La couche {nom_couche} a été ajoutée au projet QGIS.")
        
        #-------------------------------------------------------------------------------------------------------- 
        #         Application d'anlyses thématiques pour les couches chargées
        #--------------------------------------------------------------------------------------------------------
        for nom_couche in list(Liste_des_couches_necessaires.keys()):   
            vlayer=fonctions_LHP.getVectorLayerByName(nom_couche)
            # Configurer la symbologie pour définir la couleur des polygones
            if nom_couche==nom_couche_haies: 
                symbol= QgsFillSymbol.createSimple({'color': '#4daf0a', 'outline_color': '#4daf0a', 'outline_width': '1.2'})
                vlayer.renderer().setSymbol(symbol)
                
            if nom_couche == nom_couche_BDTOPO_haies:   
                color_topo = '#39FF14' # Définir la couleur vert fluo
                symbol= QgsLineSymbol.createSimple({'color': color_topo,'width': '0.8'})  
                vlayer.renderer().setSymbol(symbol)
                # Zoomer sur l'emprise de la couche
                self.iface = iface
                extent = vlayer.extent()
                iface.mapCanvas().setExtent(extent)
                iface.mapCanvas().refresh()
            
            if nom_couche==nom_couche_parcelles:
                symbol= QgsFillSymbol.createSimple({'color': 'transparent', 'outline_color': '#000000', 'outline_width': '0.5'})
                vlayer.renderer().setSymbol(symbol)
        
            # Forcer la mise à jour de la légende
            vlayer.triggerRepaint()       
            iface.layerTreeView().refreshLayerSymbology(vlayer.id())            
                        
        #--------------------------------------------------------------------------------------------------------  
        #                fabrication de la liste necessaire à la combobox et aux traitements
        #--------------------------------------------------------------------------------------------------------  

        try:
            global Liste_Pacage,Couche_Parcelles
            Liste_Pacages=[""]
            Couche_Parcelles=fonctions_LHP.getVectorLayerByName(nom_couche_parcelles)
            feat_parcelle=QgsFeature()
            # on charge les données numéros de pacages dans une liste
            for feat_parcelle in Couche_Parcelles.getFeatures():
                pacage=feat_parcelle[0] # équivalent à feat_parcelle['PACAGE']
                if pacage not in Liste_Pacages: Liste_Pacages.append(pacage) 
        except: iface.messageBar().pushMessage('Pb',"Attention impossible de charger les couches nécessaires, vérifier l'aide!", Qgis.Warning)                                 
        #-----------------------------------------------------------------------------------------------------------
        #                                   Fabrication de l'interface   
        #-----------------------------------------------------------------------------------------------------------
        Dialog.setObjectName("Dialog")
        Dialog.resize(QtCore.QSize(QtCore.QRect(0,0,600,300).size()).expandedTo(Dialog.minimumSizeHint()))
                
        #Exemple de QLabel de Num PAcage
        self.label = QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(15,15,130,23))
        self.label.setObjectName("label")
        self.label.setText("<b>Entrer code PACAGE : </b>")
        
        # Créer un QLineEdit pour la saisie de texte
        self.text_input = QLineEdit(self)
        self.text_input.setGeometry(QtCore.QRect(135, 15, 450, 23))
        self.text_input.setObjectName("TextInput")
        
        #Exemple de QLabel de Num PAcage
        self.label = QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(15,55,130,23))
        self.label.setObjectName("label2")
        self.label.setText("<b>ou selectionner : </b>")
        
        #definition QParcelles_ComboBox  
        self.Parcelles_ComboBox = QComboBox(Dialog)
        self.Parcelles_ComboBox.setGeometry(QtCore.QRect(135,55,450,23))
        self.Parcelles_ComboBox.setObjectName("ParcellesComboBox")
        Liste_Pacages.sort()
        for i in range(len(Liste_Pacages)):  self.Parcelles_ComboBox.addItem(Liste_Pacages[i])


        #Exemple de QLabel de distance tampon
        self.label = QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(15,84,400,23))
        self.label.setObjectName("label_tampon")
        self.label.setText("<b>Distance Tampon de recherche des linéaires(m): </b>")
        
        # Créer un QLineEdit pour la saisie de texte
        self.tampon = QLineEdit(self)
        self.tampon.setGeometry(QtCore.QRect(480, 84, 32, 23))
        self.tampon.setObjectName("Dtampon")
        self.tampon.setText(str(d_buffer))
        
        #Exemple de QPushButton
        self.Select_haies = QPushButton(Dialog)
        self.Select_haies.setMinimumSize(QtCore.QSize(180, 20))
        self.Select_haies.setMaximumSize(QtCore.QSize(360, 20))        
        self.Select_haies.setGeometry(QtCore.QRect(135, 120, 450, 23))
        self.Select_haies.setObjectName("ExportRapportsButton")
        self.Select_haies.setText("Lancer la sélection des haies ! ")
        
        #Exemple de ProgressBar
        self.label_progress_bar = QLabel(Dialog)
        self.label_progress_bar.setGeometry(QtCore.QRect(15,160,100,15))
        self.label_progress_bar.setObjectName("label")
        self.label_progress_bar.setText("<u>Selection des haies</u>")
        
        self.progressBar = QProgressBar(Dialog)
        self.progressBar.setProperty("value", 0)
        self.progressBar.setMinimumSize(QtCore.QSize(450, 15))
        self.progressBar.setMaximumSize(QtCore.QSize(450, 15))
        self.progressBar.setGeometry(QtCore.QRect(135,160,450,15))
        self.progressBar.setAlignment(QtCore.Qt.AlignCenter)
        self.progressBar.setTextVisible(True)
        self.progressBar.setObjectName("progressBar")
        self.progressBar.setStyleSheet(
            """QProgressBar {border: 2px solid grey; border-radius: 5px; text-align: center;}"""
            """QProgressBar::chunk {background-color: #6C96C6; width: 20px;}"""
            )
        #Pose a minima une valeur de la barre de progression / slide contrôle
        self.progressBar.setValue(0)
       
       
        self.label = QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(15,180,300,18))
        self.label.setObjectName("label")
        self.label.setText("<b>Choisir un dossier d'export des résultats : </b>")
        
        self.folder_widget = QgsFileWidget(Dialog)
        # https://api.qgis.org/api/classQgsFileWidget.html#a08386cb46b9515dd50193a6de73d1db2
        self.folder_widget.setGeometry(QtCore.QRect(15,205,550,18))
        self.folder_widget.setObjectName("Chemin")
        #https://gis.stackexchange.com/questions/463676/where-in-qgis-plugin-code-should-i-set-the-qgsfilewidget-to-getdirectory
        self.folder_widget.setStorageMode(QgsFileWidget.StorageMode.GetDirectory)
    
        
        #Exemple de QPushButton
        self.CloseButton = QPushButton(Dialog)
        self.CloseButton.setMinimumSize(QtCore.QSize(70, 20))
        self.CloseButton.setMaximumSize(QtCore.QSize(70, 20))        
        self.CloseButton.setGeometry(QtCore.QRect(510, 240,70, 20))
        self.CloseButton.setObjectName("CloseButton")
        self.CloseButton.setText(" Quitter !")
        
        #Exemple de QPushButton
        self.aboutButton = QPushButton(Dialog)
        self.aboutButton.setMinimumSize(QtCore.QSize(80, 20))
        self.aboutButton.setMaximumSize(QtCore.QSize(80, 20))        
        self.aboutButton.setGeometry(QtCore.QRect(15, 240, 80, 23))
        self.aboutButton.setObjectName("aboutButton")
        self.aboutButton.setText(" A propos...")
        
        #Exemple de QPushButton
        self.ExportRapports = QPushButton(Dialog)
        self.ExportRapports.setMinimumSize(QtCore.QSize(180, 20))
        self.ExportRapports.setMaximumSize(QtCore.QSize(360, 20))        
        self.ExportRapports.setGeometry(QtCore.QRect(135, 240,360, 23))
        self.ExportRapports.setObjectName("ExportRapportsButton")
        self.ExportRapports.setText(" Produire exports et cartes éventuelles !")
        
        

        #-----------------------------------------------------------------------------------------------------------
        #                                    Connexion des slots et des actions liées
        #-----------------------------------------------------------------------------------------------------------
        self.Select_haies.clicked.connect(self.onCombo)
        self.Parcelles_ComboBox.activated[str].connect(self.selectText)
        self.aboutButton.clicked.connect(self.doAbout)
        self.CloseButton.clicked.connect(Dialog.reject)
        self.ExportRapports.clicked.connect(self.Exports)
        self.folder_widget.fileChanged.connect(self.onCombo4)
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
         
    #-----------------------------------------------------------------------------------------------------------   
    #                                      Définitions des actions que lancent les slots   
    #-----------------------------------------------------------------------------------------------------------
    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle("Instruction LHP")
        
    def selectText(self):
        global code_pacage
        # Récupérer le code pacage de la combobox
        code_pacage = str(self.Parcelles_ComboBox.currentText())
        
    def onCombo(self):
        ## Extraction des parcelles ayant le numero PACAGE 
        global pacage, orange 
        orange='#ff9e17'
        # Récupérer le texte saisi pour le pacage
        text_pacage = str(self.text_input.text())
        distance_buffer = str(self.tampon.text())
        # ou text_pacage = "{s}".format(self.text_input.text)
        Selection_pacage=""
        if Selection_pacage == (""):
            if  text_pacage: # Vérifier si le texte n'est pas vide
                if not text_pacage.startswith("0"): # Vérifier si la chaîne ne commence par '0'
                    message = f"le numéro de pacage commence par '{text_pacage[:3]}',\n normalement c'est 021, n'oubliez pas le 0 !"
                    QMessageBox.information(None, "Information:", message)
                     
                elif len(text_pacage) != 9:
                    QMessageBox.information(None,"Information:"," le numéro de pacage doit avoir 9 caractères. ")
                elif len(text_pacage) == 9:
                    Selection_pacage=text_pacage
                    self.text_input.clear()  # Effacer le texte dans le QLineEdit après l'ajout
            elif  code_pacage !=(""):
                Selection_pacage=code_pacage
            else:
                QMessageBox.information(None,"Information:"," Il y faut renseigner ou sélectionner un numéro de pacage avant de cliquer sur ce bouton")
                
        if Selection_pacage != (""):
            #Sélection des polygones des parcelles correspondant au code pacage
            pacage = str(Selection_pacage)
            #expression = "PACAGE = pacage "   
            exp = " \"PACAGE\" ='{}' ".format(pacage)
            Couche_Parcelles.selectByExpression(exp)
            iface.mapCanvas().setSelectionColor( QColor("orange") )
            self.iface = iface
            self.iface.mapCanvas = iface.mapCanvas
            self.iface.mapCanvas().refresh()   
            #QMessageBox.information(None,"Information:"," Il y a "+str(tot_parcelle_select)+ " parcelles liées à ce numéro de pacage")
            
            global layer_Point_Pacage,Dico_parcelles,Long_Tot_Haies,Long_Tot_TOPO_Haies,Long_Tot_TOPO_Haies_intersection,Long_Tot_TOPO_Haies_buffer
            global DeuxPourc,DeuxPourcBDTOPO,DeuxPourcBDTOPO_intersection,Couche_Haies,BDTOPO_Haies,tot_parcelle_select,Long_Tot_TOPO_Haies_buffer,DeuxPourcBDTOPO_buffer
            tot_parcelle_select=len(Couche_Parcelles.selectedFeatures())
            Dico_parcelles={}
            Long_Tot_Haies=0
            Long_Tot_TOPO_Haies=0
            Long_Tot_TOPO_Haies_intersection=0
            Long_Tot_TOPO_Haies_buffer=0
            
            Couche_Haies=fonctions_LHP.getVectorLayerByName(nom_couche_haies)
            BDTOPO_Haies=fonctions_LHP.getVectorLayerByName(nom_couche_BDTOPO_haies)
            
            counterProgess=0
            # On va chercher toutes les haies intersectées mais surtout pas par parcelle 
            # mais au total, car une haie peut intersecter deux parcelles ayant même code PACAGE!
            ListIdHaie=[] 
            ListID_BDTOPO_Haie=[]
            # Créer un index spatial des objets haies pour gagner en vitesse de traitement
            index_haies = QgsSpatialIndex()
            index_haies = QgsSpatialIndex(Couche_Haies.getFeatures()) 
            index_BDTOPO_haies = QgsSpatialIndex()
            index_BDTOPO_haies = QgsSpatialIndex(BDTOPO_Haies.getFeatures()) 
            #https://docs.qgis.org/3.34/en/docs/pyqgis_developer_cookbook/vector.html
            
            selected_features=Couche_Parcelles.selectedFeatures()
            # on va créer un  tampon unique des parcelles à la distance distance_buffer pour créer une hypothèse buffer avec BDTOPO
            buffer_parcelle=fonctions_LHP.create_buffer_geometry(selected_features, distance_buffer)
            intersection_buffer=index_BDTOPO_haies.intersects(buffer_parcelle.boundingBox())
            for hid in intersection_buffer:
                # get the feature geometry by the id from the index
                feature_haie=BDTOPO_Haies.getFeature(hid)
                hgeom=feature_haie.geometry()
                # Calculer la géométrie de l'intersection
                intersection_buff_geom = buffer_parcelle.intersection(hgeom)
                L_intersection_buffer=float(intersection_buff_geom.length())
                Long_Tot_TOPO_Haies_buffer+=L_intersection_buffer # on découpe avec itersection donc pas de comptage multiple d'un même linéaire !
                          
            for feat_parcelle in selected_features: 
                counterProgess+=1
                id_parcelle= feat_parcelle.id()
                geom_parcelle = feat_parcelle.geometry()
                bbox_parcelle = geom_parcelle.boundingBox()
                XMIN=(geom_parcelle.boundingBox()).xMinimum()
                YMIN=(geom_parcelle.boundingBox()).yMinimum()
                XMAX=(geom_parcelle.boundingBox()).xMaximum()
                YMAX=(geom_parcelle.boundingBox()).yMaximum()
                feat_haies=QgsFeature()
                # Intersects par index
                intersection=index_haies.intersects(bbox_parcelle)
                id_haie=None
                for hid in intersection:
                    # get the feature geometry by the id from the index
                    feature_haie=Couche_Haies.getFeature(hid)
                    hgeom=feature_haie.geometry()
                    try:
                        if geom_parcelle.intersects(hgeom):# ou tout aussi bien if hgeom.intersects(geom_parcelle):  
                        # on vérifie alors si en plus de la boundingBox, les géométries des objets s'intersectent
                            id_haie = int(hid)
                        """    
                        if isinstance(feature_haie['LONGUEUR'], QVariant):
                            Longueur = feature_haie['LONGUEUR'].toDouble()[0]  # Convertir QVariant en double
                        else: Longueur = float(feature_haie['LONGUEUR'])
                        """
                        # après avoir ajouter un champ long_m qui vaut  round($area/LARGEUR,2) si LONGUEUR est null dans la couche
                        Longueur = float(feature_haie['long_m'])
                        # Vérifier si la valeur n'est pas déjà dans la liste pour ne pas compter deux fois le linéaire
                        if id_haie is not None and id_haie not in ListIdHaie:                    
                            ListIdHaie.append(id_haie)
                            Long_Tot_Haies+=Longueur
                    except KeyError:
                        print(f"No geometry with feature id {hid} exists in the index.")
                
                # fabrication de stats pour la BDTOPO Haie
                intersec_TOPO=index_BDTOPO_haies.intersects(bbox_parcelle)
                id_BDTOPO_Haie=None
               
                for hid in intersec_TOPO:
                    # get the feature geometry by the id from the index
                    feature_haie=BDTOPO_Haies.getFeature(hid)
                    hgeom=feature_haie.geometry()
                    try:
                        if geom_parcelle.intersects(hgeom):# ou tout aussi bien if hgeom.intersects(geom_parcelle):  
                        # on vérifie alors si en plus de la boundingBox, les géométries des objets s'intersectent
                            id_BDTOPO_Haie = int(hid)
                            # Calculer la géométrie de l'intersection
                            intersection_geom = geom_parcelle.intersection(hgeom)
                            L_intersection=float(intersection_geom.length())
                            # après aboir ajouter un champ long_m qui vaut  round($area/LARGEUR,2) si LONGUEUR est null dans la couche pac
                            Longueur = float(hgeom.length())
                            Long_Tot_TOPO_Haies_intersection+=L_intersection # on découpe avec itersection donc pas de comptage multiple d'un même linéaire !
                        
                        # Vérifier si la valeur n'est pas déjà dans la liste pour ne pas compter deux fois le linéaire dans le cas sans intersection
                        if id_BDTOPO_Haie is not None and id_BDTOPO_Haie not in ListID_BDTOPO_Haie:                    
                            ListID_BDTOPO_Haie.append(id_BDTOPO_Haie)
                            Long_Tot_TOPO_Haies+=Longueur
                            
                    except KeyError:
                        print(f"No geometry with feature id {hid} exists in the index.")
                # on charge les données par parcelle correspondant à un pacage dans un dictionnaire  pour déterminer au final l'emprise de l'ensemble des parcelles
                Dico_parcelles[id_parcelle]=[XMIN,YMIN,XMAX,YMAX,ListIdHaie,ListID_BDTOPO_Haie]
                zPercent = int(100 * counterProgess / int(tot_parcelle_select))
                self.progressBar.setValue(zPercent)
            Long_Tot_Haies=round(Long_Tot_Haies,2)
            DeuxPourc=round(Long_Tot_Haies/100*2,2)  
            # pour BDTOPO            
            Long_Tot_TOPO_Haies=round(Long_Tot_TOPO_Haies)
            DeuxPourcBDTOPO=round(Long_Tot_TOPO_Haies/100*2)   
            Long_Tot_TOPO_Haies_intersection=round(Long_Tot_TOPO_Haies_intersection)
            DeuxPourcBDTOPO_intersection=round(Long_Tot_TOPO_Haies_intersection/100*2)  
            Long_Tot_TOPO_Haies_buffer=round(Long_Tot_TOPO_Haies_buffer)
            DeuxPourcBDTOPO_buffer=round(Long_Tot_TOPO_Haies_buffer/100*2)  
              
            self.Parcelles_ComboBox.clear()
            if len(ListIdHaie)==0:
                message_final=''
                message_final=" La sélection du numéro de PACAGE "+str(pacage)
                message_final=message_final+ " \nrenvoie: "+str(tot_parcelle_select)+" parcelles. \n\nmais sans le moindre mètre linéaire de haie associé."
                QMessageBox.information(None,"Résultat consultation:", message_final)
                Q
            else:
                message_final_ok =''
                message_final_ok = " La sélection du numéro de PACAGE: "+str(pacage)
                message_final_ok += " renvoie "+str(tot_parcelle_select)
                message_final_ok += " parcelles. \n\n"
                message_final_ok += "- qui totalisent un linéaire de haies d'après couche PAC de :  " 
                message_final_ok +=  str(Long_Tot_Haies)+" mètres !" 
                message_final_ok += "\n2% de cette valeur correspond à : "
                message_final_ok +=  str(DeuxPourc)+ " mètres.\n\n"
                message_final_ok += "- qui totalisent un linéaire de haies d'après la couche Haie de la BDTOPO de V3-4  \n"
                message_final_ok += "( hypothèse haute = une partie au moins des objets haies intersecte les parcelles):      "
                message_final_ok += str(Long_Tot_TOPO_Haies)+" mètres !" 
                message_final_ok += "\n2% de cette valeur correspond à : "
                message_final_ok +=  str(DeuxPourcBDTOPO)+ " mètres.\n\n"
                message_final_ok += "( hypothèse basse = seules les parties de haies strictement dans les parcelles sont comptées):      "
                message_final_ok += str(Long_Tot_TOPO_Haies_intersection)+" mètres !" 
                message_final_ok += "\n2% de cette valeur correspond à : "
                message_final_ok += str(DeuxPourcBDTOPO_intersection)+ " mètres.\n\n"
                message_final_ok += "( hypothèse avec tampon = seules les parties de haies jusqu'à "+str(distance_buffer)+"m des parcelles sont comptées):      "
                message_final_ok += str(Long_Tot_TOPO_Haies_buffer)+" mètres !" 
                message_final_ok += "\n2% de cette valeur correspond à : "
                message_final_ok += str(DeuxPourcBDTOPO_buffer)+ " mètres.\n\n"
                
                QMessageBox.information(None,"Résultat consultation:",message_final_ok)
                #select_features_by_ids(layer_name, feature_ids)
                # on sélectionne les id de haies dans les couches pour permettre les exports des selected features
                fonctions_LHP.select_features_by_ids(nom_couche_haies, ListIdHaie)
                fonctions_LHP.select_features_by_ids(nom_couche_BDTOPO_haies, ListID_BDTOPO_Haie)
            # on zoome sur la sélection des parcelles
            global  XMINF,YMINF,XMAXF,YMAXF
            XMINF,YMINF,XMAXF,YMAXF=0,0,0,0
            first=True
            for id_parcelle in  Dico_parcelles.keys():
                XMIN=Dico_parcelles[id_parcelle][0]
                YMIN=Dico_parcelles[id_parcelle][1]
                XMAX=Dico_parcelles[id_parcelle][2]
                YMAX=Dico_parcelles[id_parcelle][3]
                if first: 
                    first=False
                    XMINF,YMINF,XMAXF,YMAXF=XMIN,YMIN,XMAX,YMAX
                else:
                    if XMINF > XMIN: XMINF = XMIN
                    if YMINF > YMIN: YMINF = YMIN
                    if XMAXF < XMAX: XMAXF = XMAX
                    if YMAXF < YMAX: YMAXF = YMAX
            self.iface = iface
            self.iface.mapCanvas = iface.mapCanvas
            self.iface.mapCanvas().refresh()
            self.zoom_extent_parcelle(XMINF,YMINF,XMAXF,YMAXF)
            #creation d'une couche avec un point contenant en attribut les résultats des linéaires calculés
            # on crée une couche avec un point au centre des parcelles pour avoir un tableau récapitulatif
            layer_Point_Pacage=fonctions_LHP.creation_point_resultat(XMINF,YMINF,XMAXF,YMAXF,Long_Tot_Haies,DeuxPourc,Long_Tot_TOPO_Haies,DeuxPourcBDTOPO,Long_Tot_TOPO_Haies_intersection,DeuxPourcBDTOPO_intersection,pacage,Long_Tot_TOPO_Haies_buffer,DeuxPourcBDTOPO_buffer,distance_buffer)
            
            
    def onCombo4(self):
        global Selection_repertoire 
        Selection_repertoire = self.folder_widget.filePath()
      
       
    def Exports(self):
        distance_buffer = str(self.tampon.text())
        # Définir le nom du sous-dossier
        date = datetime.strftime(datetime.now(), "%Y_%m_%d")
        date_H_M=datetime.strftime(datetime.now(), "%Y_%m_%d_%Hh_%Mmin")
        rep_out = 'Resultat_Longueur_Haies_Pacage_' + str(pacage)+'_'+str(date)
        # Chemin complet du sous-dossier
        rep_out_path = os.path.join(Selection_repertoire, rep_out)
        #QMessageBox.information(None,"Avertissement"," Les couches correspondantes seront sauvegardées sur :\n\n "+str(rep_out_path))
            
        # Créer le sous-dossier s'il n'existe pas
        if not os.path.exists(rep_out_path):
            os.makedirs(rep_out_path)
        # on sauvegarde la cocuhe de point créée précédemment
        nom_layer_Point_Pacage = 'resultat_parcelles_pacage_' + str(pacage)
        output_file_path_layer_Point_Pacage=os.path.join(rep_out_path, nom_layer_Point_Pacage + '.shp')
        result = processing.run("qgis:savefeatures", {
                'INPUT': layer_Point_Pacage,
                'OUTPUT': output_file_path_layer_Point_Pacage
            })
        nom_couche_sortie_parcelles = 'parcelles_pacage_' + str(pacage)
        nom_couche_sortie_haies = 'haies_pacage_' + str(pacage) 
        nom_couche_sortie_BDTOPO_haies = 'BDTOPO_haies_pacage_' + str(pacage) 
        output_file_path_parcelles = os.path.join(rep_out_path, nom_couche_sortie_parcelles + '.shp')
        output_file_path_haies = os.path.join(rep_out_path, nom_couche_sortie_haies + '.shp')
        output_file_path_BDTOPO_haies = os.path.join(rep_out_path, nom_couche_sortie_BDTOPO_haies + '.shp')
        
        # Appeler l'algorithme de traitement pour sauvegarder les éléments sélectionnés
        result = processing.run("qgis:saveselectedfeatures", {
            'INPUT': Couche_Parcelles,
            'OUTPUT': output_file_path_parcelles
        })
        
        result = processing.run("qgis:saveselectedfeatures", {
            'INPUT': Couche_Haies,
            'OUTPUT': output_file_path_haies
        })
        
        result = processing.run("qgis:saveselectedfeatures", {
            'INPUT': BDTOPO_Haies,
            'OUTPUT': output_file_path_BDTOPO_haies
        })
        
        # on ajoute les couches sauvegardées avec les seuls éléments correspondant au pacage
        layer_parcelles = QgsVectorLayer(output_file_path_parcelles,  nom_couche_sortie_parcelles, "ogr")
        layer_haies = QgsVectorLayer(output_file_path_haies,  nom_couche_sortie_haies, "ogr")
        layer_BDTOPO_haies = QgsVectorLayer(output_file_path_BDTOPO_haies,  nom_couche_sortie_BDTOPO_haies, "ogr")
        QgsProject.instance().addMapLayer(layer_parcelles)
        QgsProject.instance().addMapLayer(layer_haies)
        QgsProject.instance().addMapLayer(layer_BDTOPO_haies)
        
        root = QgsProject.instance().layerTreeRoot()
        
        #On applique des analyses thématiques à ces couches résultat
        color_parcelles='#000000' # noir !
        symbol_parcelles = QgsFillSymbol.createSimple({'color': 'transparent', 'outline_color': color_parcelles, 'outline_width': '0.6'})
        layer_parcelles.renderer().setSymbol(symbol_parcelles)
        # Forcer la mise à jour de la légende
        layer_parcelles.triggerRepaint()       
        iface.layerTreeView().refreshLayerSymbology(layer_parcelles.id())   
        
        #color_haies='#4daf0a'   # vert sombre
        color_haies='#cd5c5c'   #Rouge vif : '#ff0000' Rouge foncé : '#8b0000' # Rouge brique : '#b22222' #Rouge tomate : '#ff6347' #Rouge indien : '#cd5c5c'
        symbol_haies = QgsFillSymbol.createSimple({'color': color_haies, 'outline_color': color_haies, 'outline_width': '1'})
        layer_haies.renderer().setSymbol(symbol_haies)
        # Forcer la mise à jour de la légende
        layer_haies.triggerRepaint()       
        iface.layerTreeView().refreshLayerSymbology(layer_haies.id())     
        
        color_topo = '#39FF14' # Définir la couleur vert fluo
        symbol_BDTOPO_haies = QgsLineSymbol.createSimple({'color': color_topo,'width': '0.5'}) # vert fluo
        layer_BDTOPO_haies.renderer().setSymbol(symbol_BDTOPO_haies)
        # Forcer la mise à jour de la légende
        layer_BDTOPO_haies.triggerRepaint()       
        iface.layerTreeView().refreshLayerSymbology(layer_BDTOPO_haies.id()) 
        
        # Exporter les styles associés
        style_path_parcelles = os.path.join(rep_out_path, nom_couche_sortie_parcelles + '.qml')
        style_path_haies = os.path.join(rep_out_path, nom_couche_sortie_haies + '.qml')
        style_path_BDTOPO_haies = os.path.join(rep_out_path, nom_couche_sortie_BDTOPO_haies + '.qml')
        layer_parcelles.saveNamedStyle(style_path_parcelles)
        layer_haies.saveNamedStyle(style_path_haies)
        layer_BDTOPO_haies.saveNamedStyle(style_path_BDTOPO_haies)
        
        # Eteindre les couches de départ
        for nom_couche in list(Liste_des_couches_necessaires.keys()):
            couche_concernee = QgsProject.instance().mapLayersByName(nom_couche)[0]
            QgsProject.instance().layerTreeRoot().findLayer(couche_concernee.id()).setItemVisibilityChecked(False)
            
        self.iface = iface
        iface.mapCanvas().refresh()
        
        # ------------------------------------------------------------------------------------------------------------
        #                                Production des exports cartographiques    
        # ------------------------------------------------------------------------------------------------------------
      
        project = QgsProject.instance()             #gets a reference to the project instance
        manager = project.layoutManager()           #gets a reference to the layout manager
        layout = QgsPrintLayout(project)            #makes a new print layout object, takes a QgsProject as argument
        #--------------------------------------------------------------------------------------------------------------------   
        #                  On s'assure qu'il n'y pas de layout en mémoire (source de messages d'erreurs bloquants)
        #---------------------------------------------------------------------------------------------------------------------  
        layouts_list = manager.printLayouts()
        for layout in layouts_list:
            manager.removeLayout(layout)

        # on doit générer la liste des noms de l'ensemble des parcelles et des communes 
        rapport_name='Rapport_des_parcelles_correspondant_au_PACAGE_'+str(pacage) 
        
        fonctions_LHP.Exports_cartographiques(rep_out_path,rapport_name,layer_haies,layer_BDTOPO_haies,layer_parcelles,project,manager,XMINF,YMINF,XMAXF,YMAXF,Long_Tot_Haies,DeuxPourc,Long_Tot_TOPO_Haies,DeuxPourcBDTOPO,Long_Tot_TOPO_Haies_intersection,DeuxPourcBDTOPO_intersection,Long_Tot_TOPO_Haies_buffer,DeuxPourcBDTOPO_buffer,distance_buffer,pacage,tot_parcelle_select)     
        QMessageBox.information(None,"Fin des traitements"," Les exports cartographiques correspondants sont sauvegardés sur :\n\n "+str(rep_out_path))
        
        # https://api.qgis.org/api/3.28/structQgsLayoutExporter_1_1PdfExportSettings.html#a93ddb66c1e1f541a1bed511a41f9e396
        #
        # on va générer les inputs de la fonction qui génère le GeoPDF
        # rappel: def Exports_GeoPDF(path_name,id_carte,rapport_name,projet,manager,emprise_parcelles):
        # le chemin est déjà défini
        #
        # on devra choisir d'incorporer ou non une legende selon la variable globale nb_de_couches
        # cela se fera au niveau de la fonction fonctions_LHP.Exports_GeoPDF à la création du layout
        # d'après la liste de couches intersecteées avec len(liste)
        #            On procède comme pour un export Cartographique sans carte  
    
    def doAbout(self):
        d = doAbout_LHP.Dialog()
        d.exec_()
     
    def zoom_extent_parcelle(self,xmin,ymin,xmax,ymax):
        xmin=int(xmin)
        ymin=int(ymin)
        xmax=int(xmax)
        ymax=int(ymax)
        #On agrandit l'emprise au cas ou (min 100m)
        if xmax-xmin<100:
            xmin = xmin - (100-(xmax-xmin))/2
            xmax = xmax + (100-(xmax-xmin))/2
        if ymax-ymin<100:
            ymin = ymin - (100-(ymax-ymin))/2
            ymax = ymax + (100-(ymax-ymin))/2
        #Creation du rectangle d'emprise :
        rec = QgsRectangle(xmin, ymin, xmax, ymax)
        self.iface = iface
        self.iface.mapCanvas = iface.mapCanvas
        self.iface.mapCanvas().setExtent(rec)
        self.iface.mapCanvas().refresh()

